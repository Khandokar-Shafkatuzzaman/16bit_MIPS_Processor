# 16bits-MIPS-Processor-
I have construct a 16bit CPU using Microprocessor without interlocked pipeline stages (MIPS) architecture that can do arithmetic logic sifts left and right , jump and branch.   
